# HappyBirthday-Script

Simple happy birthday script build using bootstrap 4

Use for learn.


Demo Site : <a href="https://wafarifki.github.io/HappyBirthday-Script/">See Demo</a>


<b>#Mari Mengenal Saya Lebih Dekat :D </b>
<br><a href="https://instagram.com/wafarifki_" target="_blank">Instagram</a>
<br><a href="https://facebook.com/bekasiHACKERlive" target="_blank">Facebook</a>
<br><a href="https://wafarifki.tk" target="_blank">Situs Web</a>
